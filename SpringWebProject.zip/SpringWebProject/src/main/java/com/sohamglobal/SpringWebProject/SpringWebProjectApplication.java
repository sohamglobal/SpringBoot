package com.sohamglobal.SpringWebProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebProjectApplication.class, args);
	}

}
