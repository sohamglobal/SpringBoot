package com.sohamglobal.SpringWebProject;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.sohamglobal.models.*;

@Controller
public class SohamController {
	
	@RequestMapping("/soham")
	public String index()
	{
		return "index.jsp";
	}
	
	@RequestMapping("/check")
	public String check(String userid,String pswd)
	{
		Authenticate au=new Authenticate();
		au.setUserid(userid);
		au.setPswd(pswd);
		if(au.getStatus().equals("success"))
		{
			
			return "User.jsp";
		}
		else
			return "Failure.jsp";
	}

}
