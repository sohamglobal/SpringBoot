package com.sohamglobal.models;

public class Authenticate {
	private String userid;
	private String pswd;
	private String status;
	
	public Authenticate()
	{
		status="";
	}
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPswd() {
		return pswd;
	}
	public void setPswd(String pswd) {
		this.pswd = pswd;
		checkPass();
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String stat) {
		this.status = status;
	}
	
	//Function to check userid and password
	private void checkPass()
	{
		if(pswd.equals("springboot"))
			status="success";
		else
			status="failed";
	}

}
